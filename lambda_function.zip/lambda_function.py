from boto.cloudfront.distribution import Distribution
from boto.cloudfront import CloudFrontConnection
from botocore.signers import CloudFrontSigner
import datetime
import rsa

def rsa_signer(message):
    private_key = open('cloudfront-test-key.pem', 'r').read()
    return rsa.sign(message, rsa.PrivateKey.load_pkcs1(private_key.encode('utf8')),'SHA-1')

def lambda_handler(event, context):
    url = "https://dy4htuqalq0et.cloudfront.net"
    expire_date = datetime.datetime(2023, 6, 2)
    key_id = ''
    cf_signer = CloudFrontSigner(key_id, rsa_signer)
    signed_url = cf_signer.generate_presigned_url(url, date_less_than=expire_date)
    print(signed_url)
    return True